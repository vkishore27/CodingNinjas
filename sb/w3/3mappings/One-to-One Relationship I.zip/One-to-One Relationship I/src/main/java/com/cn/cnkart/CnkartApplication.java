package com.cn.cnkart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CnkartApplication {

	public static void main(String[] args) {
		SpringApplication.run(CnkartApplication.class, args);
	}

}
